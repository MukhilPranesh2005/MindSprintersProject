let users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
let products = JSON.parse(localStorage.getItem('products')) || [];
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let purchases = JSON.parse(localStorage.getItem('purchases')) || [];

function saveData() {
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('currentUser', JSON.stringify(currentUser));
  localStorage.setItem('products', JSON.stringify(products));
  localStorage.setItem('cart', JSON.stringify(cart));
  localStorage.setItem('purchases', JSON.stringify(purchases));
}

function showPage(id) {
  document.querySelectorAll('.container').forEach(el => el.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
  if (id === 'dashboardPage') renderMyProducts();
  if (id === 'productsPage') renderProducts();
  if (id === 'cartPage') renderCart();
  if (id === 'purchasesPage') renderPurchases();
}

function register() {
  let user = {
    username: document.getElementById('regUsername').value,
    email: document.getElementById('regEmail').value,
    password: document.getElementById('regPassword').value
  };
  users.push(user);
  saveData();
  alert('Registered successfully!');
  showPage('loginPage');
}

function login() {
  let email = document.getElementById('loginEmail').value;
  let pass = document.getElementById('loginPassword').value;
  let user = users.find(u => u.email === email && u.password === pass);
  if (user) {
    currentUser = user;
    saveData();
    alert('Login successful!');
    showPage('dashboardPage');
  } else {
    alert('Invalid credentials');
  }
}

function updateProfile() {
  if (!currentUser) return;
  currentUser.username = document.getElementById('profileUsername').value;
  saveData();
  alert('Profile updated!');
}

function createProduct() {
  if (!currentUser) return alert('Login first!');
  let prod = {
    id: Date.now(),
    owner: currentUser.email,
    title: document.getElementById('prodTitle').value,
    desc: document.getElementById('prodDesc').value,
    category: document.getElementById('prodCategory').value,
    price: document.getElementById('prodPrice').value,
    image: document.getElementById('prodImage').value || 'https://via.placeholder.com/150'
  };
  products.push(prod);
  saveData();
  renderMyProducts();
  alert('Product added!');
}

function renderMyProducts() {
  let container = document.getElementById('myProducts');
  container.innerHTML = '';
  products.filter(p => p.owner === currentUser?.email).forEach(p => {
    container.innerHTML += `<div class='product-card'>
      <h4>${p.title}</h4>
      <p>$${p.price}</p>
      <button onclick="deleteProduct(${p.id})">Delete</button>
    </div>`;
  });
}

function deleteProduct(id) {
  products = products.filter(p => p.id !== id);
  saveData();
  renderMyProducts();
}

function renderProducts() {
  let search = document.getElementById('searchBox').value.toLowerCase();
  let cat = document.getElementById('filterCategory').value;
  let container = document.getElementById('allProducts');
  container.innerHTML = '';
  products.filter(p => p.title.toLowerCase().includes(search) && (!cat || p.category === cat))
    .forEach(p => {
      container.innerHTML += `<div class='product-card'>
        <img src='${p.image}' width='100%'>
        <h4>${p.title}</h4>
        <p>$${p.price}</p>
        <button onclick="addToCart(${p.id})">Add to Cart</button>
      </div>`;
  });
}

function addToCart(id) {
  let product = products.find(p => p.id === id);
  cart.push(product);
  saveData();
  alert('Added to cart!');
}

function renderCart() {
  let container = document.getElementById('cartItems');
  container.innerHTML = '';
  cart.forEach((p, i) => {
    container.innerHTML += `<div class='product-card'>
      <h4>${p.title}</h4>
      <p>$${p.price}</p>
      <button onclick="purchase(${i})">Purchase</button>
    </div>`;
  });
}

function purchase(i) {
  purchases.push(cart[i]);
  cart.splice(i, 1);
  saveData();
  renderCart();
  alert('Purchased!');
}

function renderPurchases() {
  let container = document.getElementById('purchaseItems');
  container.innerHTML = '';
  purchases.forEach(p => {
    container.innerHTML += `<div class='product-card'>
      <h4>${p.title}</h4>
      <p>$${p.price}</p>
    </div>`;
  });
}
